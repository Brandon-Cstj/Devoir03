#include <iostream>

using namespace std;          // pour �viter de r�p�ter le std:: decant les instructions comme cout, cin, endl, ...

int main()
{
	setlocale(LC_ALL, "");

	// D�claration des variables
	int semaine; // nombre de semaine
	int brut; // argent brut
	int x = 250; // recoit 250$ / semaine
	char i = 0.075; // 7.5% des ventes brut
	char o; // calcule y * i
	const int NEG = -1; // constance qui fait en sorte que le programme arrete a -1
	char total;

	cout << " Veuillez entrez le nombre de semaine ";
	cin >> semaine;



	brut = 0;

	while (brut != NEG)
	{
		cout << " Veuillez entrez l'argent brut fait en une semaine ";
		cin >> brut;

		o = brut * i; // calcule pour avoir 7.5% de l'argent brut
		total = o + semaine * x; // calcule du total
		cout << "Argent Recu " << total;

		// je ne sais pas comment faire en sorte que le programme garde toute les variables et fait un calculs par la suite,
		// je ne sais pas nonplus comment faire la moyenne de 'o' car je ne sais pas comment faire un sorte de calculer le nombre de fois que l'utilisateur rentre un nombre 'brut'

	}






}