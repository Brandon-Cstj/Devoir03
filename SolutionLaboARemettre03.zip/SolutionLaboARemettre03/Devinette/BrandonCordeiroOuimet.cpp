#include <iostream>
#include <time.h>


using namespace std;          // pour �viter de r�p�ter le std:: decant les instructions comme cout, cin, endl, ...

int main()
{
	setlocale(LC_ALL, "");

	int iRandom; // permet de m�moriser le nombre choisi al�atoirement par l�ordinateur
	int nbEssais = 1;
	int chiffre;
	int limit = 5;

	srand(time(0)); // pour activer l�al�atoire dans le programme

	iRandom = rand() % 101; // l�ordinateur calcule un nombre al�atoire entre 0 et 100 et le stocke dans iRandom


	cout << " Veuillez inscrire un num�ro entre 1 et 100 : ";
	cin >> chiffre;

	while (nbEssais <= limit)

	{


		if (chiffre == iRandom) // si le chiffre inscrit est le bon, marche pas le programme affiche que le resultat est tout le temps bon

		{
			cout << " Vous avez trouver le bon nombre! : " << iRandom;
		}
		if (chiffre < iRandom)// si le chiffre est plus petit, aide l'utilisateur a le savoir
		{
			cout << " Le chiffre est plus petit que le chiffre al�atoire, Veuilllez r�essayer ";
		}

		if (chiffre > iRandom) // si le chiffre est plus grand, aide l'utilisateur a le savoir
		{
			cout << " Le chiffre est plus grand que le chiffre al�atoire, Veuilllez r�essayer ";
		}


		else
		{
			cout << " Veuillez r�essayer : "; // marche pas, ce message est senser de s'afficher quand la premiere condition est fause,
											  // mais il affiche just le if et ne rentre jamais de else
		}

		// nbEssais++; j'ai essayer d'ecrire cela pour voir si je pouvais augmenter de 5 nombre d'essay pour voir si le programme arreterais apres

		nbEssais = nbEssais + 1; // Deuxieme metode essayer pour avoir 5 essay maximum, marche toujours pas


		cin >> nbEssais;
	}
	return 0;
}


