
#include <iostream>
#include <Windows.h>

using namespace std;          // pour �viter de r�p�ter le std:: decant les instructions comme cout, cin, endl, ...

int main()
{
	setlocale(LC_ALL, "");

	// D�claration des variables
	int semaine; // nombre de semaine
	int brut; // argent brut
	int x = 250; // recoit 250$ / semaine
	char i = 0.075; // 7.5% des ventes brut
	char o; // calcule y * i
	const int NEG = -1; // constance qui fait en sorte que le programme arrete a -1

	cout << " Veuillez entrez le nombre de semaine ";
	cin >> semaine;

	
	
	brut = 0;

	while (brut != NEG)
	{
		cout << " Veuillez entrez l'argent brut fait en une semaine ";
		cin >> brut;

		o = brut * i;

		cout << brut;



	}






}